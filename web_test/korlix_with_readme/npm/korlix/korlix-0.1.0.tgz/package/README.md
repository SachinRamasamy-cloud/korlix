# Korlix

Korlix is a frontend-first language that compiles .klx files into HTML, CSS, and JavaScript.

Create a new app:

npm create korlix@latest my-app

Or:

npm create korlix@latest

CLI:

```sh
korlix new my-app
korlix dev
korlix build
korlix check
korlix preview
```

Publish:

```sh
cd npm/korlix
npm login
npm run publish:dry
npm run publish:public
```

If your npm account has two-factor authentication enabled, pass the current
6-digit authenticator code:

```sh
npm run publish:public -- --otp=123456
```

Publish this package before publishing `create-korlix`.
